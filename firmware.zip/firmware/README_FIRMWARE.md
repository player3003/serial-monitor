# ESP32 Serial Bridge Firmware

这份代码是基于 Arduino 框架的 ESP32 固件，用于配合 Web Serial Monitor 软件，实现远程串口透传功能。

## 目录结构
```
firmware/
  └── esp32_serial_bridge/
      └── esp32_serial_bridge.ino  # 主程序代码
```

## 功能特点
1.  **WiFi 连接**：自动连接指定 WiFi。
2.  **MQTT 通信**：连接到后端部署的 MQTT Broker。
3.  **串口指令下发**：订阅 `device/{deviceId}/serial/cmd`，将收到内容写入 ESP32 物理串口。
4.  **数据上报**：监听 ESP32 物理串口 (`Serial`)，收到数据后发布到 `device/{deviceId}/serial/raw`。
5.  **远程配置**：订阅 `device/{deviceId}/config`，支持动态修改波特率。
6.  **自带校验**：
    *   **Ping/Pong**: 如果收到指令内容包含 "PING"，自动回复 "System Response: PONG"。
    *   **Heartbeat**: 每 10 秒自动发送一条心跳消息，确保前端能看到数据流动。

## 使用步骤

### 1. 准备环境
*   安装 **Arduino IDE**。
*   安装 **ESP32 开发板支持包** (Board Manager 中搜索 ESP32)。
*   安装库文件 (Sketch -> Include Library -> Manage Libraries):
    *   `PubSubClient` (by Nick O'Leary) - 用于 MQTT 通信。
    *   `ArduinoJson` (by Benoit Blanchon) - 用于解析配置 JSON。

### 2. 配置代码
打开 `esp32_serial_bridge.ino`，修改顶部的用户配置区域：

```cpp
// ================= 用户配置区域 =================
const char* ssid = "YOUR_WIFI_SSID";         // 修改为您的 WiFi 名称
const char* password = "YOUR_WIFI_PASSWORD"; // 修改为您的 WiFi 密码

const char* mqtt_server = "192.168.1.100";   // 修改您的电脑/服务器 IP
const int   mqtt_port = 1883;                // MQTT 端口，默认 1883

const char* device_id = "device_001";        // 您的设备 ID，需与网页端添加时一致
// ===============================================
```

### 3. 连接与烧录
1.  将 ESP32 开发板通过 USB 连接到电脑。
2.  在 Arduino IDE 中选择对应的开发板型号 (如 ESP32 Dev Module) 和端口。
3.  点击 **Upload** 按钮烧录代码。

## 测试验证
1.  打开 Web Serial Monitor 网页。
2.  在设备列表中确保存在 ID 为 `device_001` 的设备（如果后端开启了自动注册，收到第一条消息会自动创建）。
3.  进入控制台：
    *   你应该能每 10 秒看到一条 `HEARTBEAT` 消息。
    *   发送 `PING`，你应该能立即收到 `System Response: PONG`。
    *   将 ESP32 的 TX/RX 引脚短接（Loopback 测试），你在网页发送的任何内容都应该被回显收到。
