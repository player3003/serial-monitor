#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

// ================= 用户配置区域 =================
const char* ssid = "YOUR_WIFI_SSID";         // WiFi名称
const char* password = "YOUR_WIFI_PASSWORD"; // WiFi密码

const char* mqtt_server = "192.168.1.100";   // 后端服务器IP地址
const int   mqtt_port = 1883;                // MQTT端口

// 唯一设备ID，需与Web端一致
const char* device_id = "device_001"; 

// 定义LED引脚 (根据实际硬件修改)
const int LED_A = 2;   // 开发板板载LED通常是GPIO 2
const int LED_B = 4;   // 示例外接LED

// 默认串口参数
unsigned long serial_baud = 115200;
uint32_t serial_config = SERIAL_8N1;
// ===============================================

WiFiClient espClient;
PubSubClient client(espClient);

// Topics
String cmd_topic;
String config_topic;
String data_topic;
String status_topic;

unsigned long lastMsg = 0;
// 缓存串口数据
String serialBuffer = "";

// 模拟获取温度传感器数据
float generateRandomTemp() {
  // 返回 20.0 ~ 30.0 之间的随机数
  return 20.0 + (random(0, 100) / 10.0);
}

// 动态映射校验位等配置
uint32_t getSerialConfig(int dataBits, String parity, float stopBits) {
  // 简化实现，默认 8N1，根据需求扩展
  // 也可以写一个完善的查找表
  if(dataBits == 8 && parity == "None" && stopBits == 1) return SERIAL_8N1;
  if(dataBits == 8 && parity == "Even" && stopBits == 1) return SERIAL_8E1;
  if(dataBits == 8 && parity == "Odd" && stopBits == 1) return SERIAL_8O1;
  // ... 更多组合
  return SERIAL_8N1; 
}

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
}

// 处理接收到的MQTT消息
void callback(char* topic, byte* payload, unsigned int length) {
  String topicStr = String(topic);
  String msg = "";
  for (unsigned int i = 0; i < length; i++) {
    msg += (char)payload[i];
  }
  
  // 1. 处理指令 (透传给串口 + 新增功能指令)
  if (topicStr.equals(cmd_topic)) {
    // ---------------- 新增：LED控制指令 ----------------
    if (msg.equals("LED_A_ON")) {
        digitalWrite(LED_A, HIGH);
        String resp = "LED_A: ON (GPIO" + String(LED_A) + ")";
        client.publish(data_topic.c_str(), resp.c_str());
    } 
    else if (msg.equals("LED_A_OFF")) {
        digitalWrite(LED_A, LOW);
        String resp = "LED_A: OFF (GPIO" + String(LED_A) + ")";
        client.publish(data_topic.c_str(), resp.c_str());
    }
    else if (msg.equals("LED_B_ON")) {
        digitalWrite(LED_B, HIGH);
        String resp = "LED_B: ON (GPIO" + String(LED_B) + ")";
        client.publish(data_topic.c_str(), resp.c_str());
    }
    else if (msg.equals("LED_B_OFF")) {
        digitalWrite(LED_B, LOW);
        String resp = "LED_B: OFF (GPIO" + String(LED_B) + ")";
        client.publish(data_topic.c_str(), resp.c_str());
    }
    // ---------------- 新增：获取温度指令 ----------------
    else if (msg.equals("GET_TEMP")) {
        float temp = generateRandomTemp();
        String resp = "Temperature: " + String(temp) + "°C";
        client.publish(data_topic.c_str(), resp.c_str());
    }
    // ---------------- 新增：清除串口缓冲区指令 ----------------
    else if (msg.equals("CLEAR_SERIAL_BUFFER")) {
        serialBuffer.clear(); // 清空软件缓冲区
        Serial.flush();       // 清空硬件缓冲区
        String resp = "Serial buffer cleared (software + hardware)";
        client.publish(data_topic.c_str(), resp.c_str());
    }
    // ---------------- 原有指令保留 ----------------
    else {
        Serial.print(msg); // 其他指令透传给物理串口
        
        if (msg.indexOf("PING") >= 0) {
           client.publish(data_topic.c_str(), "System Response: PONG");
        }
        if (msg.indexOf("TEST_CONNECT") >= 0) {
           String resp = "Connection OK: Device " + String(device_id) + " is online.";
           client.publish(data_topic.c_str(), resp.c_str());
        }
    }
  }
  
  // 2. 处理配置 (修改波特率等)
  else if (topicStr.equals(config_topic)) {
    // 解析 JSON: {"baudRate": 9600, "dataBits": 8 ...}
    StaticJsonDocument<200> doc;
    DeserializationError error = deserializeJson(doc, msg);
    if (!error) {
      if (doc.containsKey("baudRate")) {
        serial_baud = doc["baudRate"];
        // 重启串口
        Serial.end();
        Serial.begin(serial_baud); // 这里简化处理，可结合 getSerialConfig 设置校验位
        delay(100);
        
        String log = "Config Applied: Baud=" + String(serial_baud);
        client.publish(status_topic.c_str(), log.c_str());
      }
    }
  }
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    String clientId = "ESP32Client-";
    clientId += String(random(0xffff), HEX);
    
    // 构建遗嘱消息 (Last Will and Testament)
    // 当连接意外断开时，Broker会自动发布此消息
    String lwtMsg = "Device Offline: " + String(device_id);
    
    // 连接 (带 LWT 参数: user=NULL, pass=NULL, willTopic, willQos=0, willRetain=false, willMsg, cleanSession=true)
    // PubSubClient connect 重载较多，使用带 will 的版本
    // boolean connect(const char* id, const char* user, const char* pass, const char* willTopic, uint8_t willQos, boolean willRetain, const char* willMessage, boolean cleanSession);
    if (client.connect(clientId.c_str(), NULL, NULL, status_topic.c_str(), 0, false, lwtMsg.c_str(), true)) {
      Serial.println("connected");
      
      // 订阅指令和配置
      client.subscribe(cmd_topic.c_str());
      client.subscribe(config_topic.c_str());
      
      // 发送上线消息
      String onlineMsg = "Device Online: " + String(device_id);
      client.publish(status_topic.c_str(), onlineMsg.c_str());
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}初始化 LED 引脚
  pinMode(LED_A, OUTPUT);
  pinMode(LED_B, OUTPUT);
  digitalWrite(LED_A, LOW);
  digitalWrite(LED_B, LOW);

  // 

void setup() {
  // 初始化物理串口
  Serial.begin(serial_baud);
  
  // 构建 Topics
  cmd_topic = "device/" + String(device_id) + "/serial/cmd";
  config_topic = "device/" + String(device_id) + "/config";
  data_topic = "device/" + String(device_id) + "/serial/raw";
  status_topic = "device/" + String(device_id) + "/serial/status";

  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // 读取物理串口数据并上报
  // 策略：积累一定长度或遇到换行发送，或者超时发送
  while (Serial.available()) {
    char c = (char)Serial.read();
    serialBuffer += c;
    
    // 如果包含换行，或者是缓冲区太长，就发送
    if (c == '\n' || serialBuffer.length() > 64) {
      if (client.connected()) {
        client.publish(data_topic.c_str(), serialBuffer.c_str());
      }
      serialBuffer = "";
    }
  }
  
  // 也可以增加超时发送逻辑（避免最后半行数据卡住）
  static unsigned long lastSerialTime = 0;
  if (serialBuffer.length() > 0 && millis() - lastSerialTime > 100) {
     if (client.connected()) {
        client.publish(data_topic.c_str(), serialBuffer.c_str());
     }
     serialBuffer = "";
     lastSerialTime = millis();
  } else if (Serial.available()) {
     lastSerialTime = millis();
  }

  // 校验功能：心跳包 (每10秒发送一次)
  // 用于验证链路是否通畅，即使没有串口数据
  unsigned long now = millis();
  if (now - lastMsg > 10000) {
    lastMsg = now;
    // 构建一个简单的 JSON 心跳供前端解析（可选），或者纯文本
    String heartbeat = "HEARTBEAT: Time=" + String(now/1000) + "s";
    client.publish(status_topic.c_str(), heartbeat.c_str());
  }
}
